#pragma once

namespace tests_cryptoTools
{


    void BitVector_Indexing_Test_Impl();
    void BitVector_Parity_Test_Impl();
    void BitVector_Append_Test_Impl();
    void BitVector_Copy_Test_Impl();
    void BitVector_Resize_Test_Impl();
}