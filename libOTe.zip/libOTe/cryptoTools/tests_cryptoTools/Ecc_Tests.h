#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 

namespace tests_cryptoTools
{

    void EccpNumber_Test();
    void EccpPoint_Test();

    void Ecc2mNumber_Test();
    void Ecc2mPoint_Test();
}