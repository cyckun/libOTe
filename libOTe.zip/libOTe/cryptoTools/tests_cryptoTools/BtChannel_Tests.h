


namespace tests_cryptoTools
{


    void BtNetwork_Connect1_Test();
    void BtNetwork_RapidConnect_Test();
    void BtNetwork_OneMegabyteSend_Test();
    void BtNetwork_ConnectMany_Test();
    void BtNetwork_CrossConnect_Test();
    void BtNetwork_ManySessions_Test();


    void BtNetwork_AsyncConnect_Test();
    void BtNetwork_std_Containers_Test();
    void BtNetwork_bitVector_Test();


    void BtNetwork_recvErrorHandler_Test();
    void BtNetwork_closeOnError_Test();
    void BtNetwork_clientClose_Test();


	void BtNetwork_SocketInterface_Test();

	void BtNetwork_AnonymousMode_Test();
	void BtNetwork_ServerMode_Test();
	void BtNetwork_CancelChannel_Test();


    void SBO_ptr_test();

}